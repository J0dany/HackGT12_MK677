# Semester Glide (Updated)

## Flask Integration (how to swap mocks for real endpoints)

This project currently includes a centralized API adapter at `lib/api.ts` that returns mock data.
When the Flask backend is ready, replace the mock implementations with `fetch()` calls to the Flask endpoints.

Example Flask routes expected:
- `GET  /api/courses` -> returns list of courses and metadata
- `GET  /api/professors?q=NAME_OR_COURSE` -> returns professor ratings/reviews (scraped or cached)
- `POST /api/optimize-plan` -> accepts optimization input and returns a planned semesters object
- `POST /api/parse-syllabus` -> accepts multipart form file upload and returns parsed deliverables

Local development:
1. Start your Flask backend on http://localhost:5000
2. Copy `.env.example` to `.env.local` and update `NEXT_PUBLIC_FLASK_API_URL` if necessary
3. Run `pnpm dev` or `npm run dev` from the Next.js project root

Notes:
- All frontend calls are funneled through `lib/api.ts`. Search for `// TODO: Replace` comments to find where to swap in real network calls.
- CORS: Ensure Flask has CORS enabled for your frontend origin during development (e.g., `flask-cors`).