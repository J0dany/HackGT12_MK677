// Mock API for Rate My Semester - Georgia Tech Integration
// TODO: Replace with actual Flask backend endpoints

export interface Course {
  id: string;
  code: string;
  name: string;
  credits: number;
  difficulty: number; // 1-5 scale
  avgGPA: number;
  professor: string;
  rating: number; // Professor rating
  workload: number; // Hours per week
  prerequisites: string[];
  semester: string[];
  description: string;
}

export interface Professor {
  id: string;
  name: string;
  department: string;
  rating: number;
  difficulty: number;
  courses: string[];
  reviews: string[];
}

export interface Major {
  id: string;
  name: string;
  department: string;
  totalCredits: number;
  requiredCourses: string[];
  electiveCourses: string[];
  prerequisites: { [key: string]: string[] };
}

export interface DegreeProgress {
  completedCourses: string[];
  remainingRequired: string[];
  remainingElectives: string[];
  totalCreditsCompleted: number;
  creditsRemaining: number;
}

export interface OptimizationStrategy {
  id: 'max-gpa' | 'graduate-fast' | 'balanced';
  name: string;
  description: string;
  priority: string;
}

export interface OptimizationResult {
  strategy: OptimizationStrategy;
  semesters: SemesterPlan[];
  totalGPA: number;
  totalWorkload: number;
  degreeProgress: number;
  graduationDate: string;
  insights: string[];
}

export interface SemesterPlan {
  semester: string;
  courses: Course[];
  totalCredits: number;
  expectedGPA: number;
  workload: number;
}

// Mock GT Course Data
const mockCourses: Course[] = [
  {
    id: "cs1301",
    code: "CS 1301",
    name: "Intro to Computing",
    credits: 3,
    difficulty: 2,
    avgGPA: 3.2,
    professor: "Dr. Smith",
    rating: 4.2,
    workload: 8,
    prerequisites: [],
    semester: ["Fall", "Spring", "Summer"],
    description: "Introduction to computer programming using Python"
  },
  {
    id: "cs1331",
    code: "CS 1331",
    name: "Object-Oriented Programming",
    credits: 3,
    difficulty: 3,
    avgGPA: 2.8,
    professor: "Dr. Johnson",
    rating: 3.8,
    workload: 12,
    prerequisites: ["CS 1301"],
    semester: ["Fall", "Spring"],
    description: "Object-oriented programming in Java"
  },
  {
    id: "cs2110",
    code: "CS 2110",
    name: "Computer Organization",
    credits: 4,
    difficulty: 4,
    avgGPA: 2.5,
    professor: "Dr. Williams",
    rating: 3.5,
    workload: 15,
    prerequisites: ["CS 1331"],
    semester: ["Fall", "Spring"],
    description: "Computer systems and assembly language programming"
  },
  {
    id: "cs3510",
    code: "CS 3510",
    name: "Design & Analysis of Algorithms",
    credits: 3,
    difficulty: 5,
    avgGPA: 2.3,
    professor: "Dr. Brown",
    rating: 4.0,
    workload: 18,
    prerequisites: ["CS 1331", "MATH 1552"],
    semester: ["Fall", "Spring"],
    description: "Algorithm design, analysis, and complexity theory"
  },
  {
    id: "math1551",
    code: "MATH 1551",
    name: "Differential Calculus",
    credits: 2,
    difficulty: 3,
    avgGPA: 2.7,
    professor: "Dr. Davis",
    rating: 3.6,
    workload: 10,
    prerequisites: [],
    semester: ["Fall", "Spring", "Summer"],
    description: "Limits, derivatives, and applications"
  },
  {
    id: "math1552",
    code: "MATH 1552",
    name: "Integral Calculus",
    credits: 4,
    difficulty: 3,
    avgGPA: 2.6,
    professor: "Dr. Wilson",
    rating: 3.7,
    workload: 12,
    prerequisites: ["MATH 1551"],
    semester: ["Fall", "Spring", "Summer"],
    description: "Integration techniques and applications"
  },
  {
    id: "phys2211",
    code: "PHYS 2211",
    name: "Physics I",
    credits: 4,
    difficulty: 4,
    avgGPA: 2.4,
    professor: "Dr. Martinez",
    rating: 3.9,
    workload: 14,
    prerequisites: ["MATH 1552"],
    semester: ["Fall", "Spring"],
    description: "Mechanics and thermodynamics"
  },
  {
    id: "engl1101",
    code: "ENGL 1101",
    name: "English Composition I",
    credits: 3,
    difficulty: 2,
    avgGPA: 3.4,
    professor: "Dr. Taylor",
    rating: 4.1,
    workload: 6,
    prerequisites: [],
    semester: ["Fall", "Spring", "Summer"],
    description: "Academic writing and research"
  }
];

const mockProfessors: Professor[] = [
  {
    id: "smith",
    name: "Dr. Smith",
    department: "Computer Science",
    rating: 4.2,
    difficulty: 2.8,
    courses: ["CS 1301"],
    reviews: ["Great for beginners", "Clear explanations", "Helpful office hours"]
  },
  {
    id: "johnson",
    name: "Dr. Johnson",
    department: "Computer Science",
    rating: 3.8,
    difficulty: 3.5,
    courses: ["CS 1331"],
    reviews: ["Challenging but fair", "Good projects", "Prepare for exams well"]
  },
  {
    id: "brown",
    name: "Dr. Brown",
    department: "Computer Science",
    rating: 4.0,
    difficulty: 4.8,
    courses: ["CS 3510"],
    reviews: ["Brilliant lecturer", "Very difficult", "Life-changing class"]
  }
];

// Mock GT Majors Data
const mockMajors: Major[] = [
  {
    id: "cs",
    name: "Computer Science",
    department: "College of Computing",
    totalCredits: 126,
    requiredCourses: ["CS 1301", "CS 1331", "CS 2110", "CS 3510", "MATH 1551", "MATH 1552"],
    electiveCourses: ["CS 4400", "CS 4641", "CS 4801", "CS 3600"],
    prerequisites: {
      "CS 1331": ["CS 1301"],
      "CS 2110": ["CS 1331"],
      "CS 3510": ["CS 1331", "MATH 1552"]
    }
  },
  {
    id: "me",
    name: "Mechanical Engineering",
    department: "College of Engineering", 
    totalCredits: 128,
    requiredCourses: ["MATH 1551", "MATH 1552", "PHYS 2211", "ME 2110", "ME 3017"],
    electiveCourses: ["ME 4056", "ME 4182", "ME 4315"],
    prerequisites: {
      "MATH 1552": ["MATH 1551"],
      "PHYS 2211": ["MATH 1552"]
    }
  },
  {
    id: "ee",
    name: "Electrical Engineering", 
    department: "College of Engineering",
    totalCredits: 128,
    requiredCourses: ["MATH 1551", "MATH 1552", "PHYS 2211", "ECE 2020", "ECE 3025"],
    electiveCourses: ["ECE 4180", "ECE 4893", "ECE 4270"],
    prerequisites: {
      "ECE 2020": ["MATH 1552"],
      "ECE 3025": ["ECE 2020"]
    }
  }
];

const optimizationStrategies: OptimizationStrategy[] = [
  {
    id: 'max-gpa',
    name: 'Maximize GPA',
    description: 'Prioritizes easier courses and lighter workloads to maintain highest possible GPA',
    priority: 'GPA optimization over speed'
  },
  {
    id: 'graduate-fast', 
    name: 'Graduate On Time',
    description: 'Focuses on completing degree requirements as quickly as possible',
    priority: 'Time to graduation'
  },
  {
    id: 'balanced',
    name: 'Balanced Approach',
    description: 'Optimizes both GPA and graduation timeline for well-rounded success',
    priority: 'GPA and timeline balance'
  }
];

// API Functions
export const getCourses = async (): Promise<Course[]> => {
  // TODO: connect Flask backend here
  // return fetch('/api/courses').then(res => res.json());
  return new Promise(resolve => {
    setTimeout(() => resolve(mockCourses), 500);
  });
};

export const getProfessors = async (): Promise<Professor[]> => {
  // TODO: connect Flask backend here
  // return fetch('/api/professors').then(res => res.json());
  return new Promise(resolve => {
    setTimeout(() => resolve(mockProfessors), 300);
  });
};

export const searchCourses = async (query: string): Promise<Course[]> => {
  // TODO: connect Flask backend here
  const allCourses = await getCourses();
  return allCourses.filter(course => 
    course.code.toLowerCase().includes(query.toLowerCase()) ||
    course.name.toLowerCase().includes(query.toLowerCase())
  );
};

export const getMajors = async (): Promise<Major[]> => {
  return new Promise(resolve => {
    setTimeout(() => resolve(mockMajors), 300);
  });
};

export const parseDegreeWorks = async (file: File): Promise<DegreeProgress> => {
  // TODO: connect Flask backend here for PDF parsing
  return new Promise(resolve => {
    setTimeout(() => {
      resolve({
        completedCourses: ["CS 1301", "MATH 1551", "ENGL 1101"],
        remainingRequired: ["CS 1331", "CS 2110", "CS 3510", "MATH 1552", "PHYS 2211"],
        remainingElectives: ["CS 4400", "CS 4641"],
        totalCreditsCompleted: 8,
        creditsRemaining: 118
      });
    }, 2000);
  });
};

export const generateOptimizedPlans = async (preferences: {
  majorId: string;
  completedCourses: string[];
  gpaGoal: number;
  creditLimit: number;
  difficultyBalance: number;
  extracurriculars: number;
}): Promise<OptimizationResult[]> => {
  // TODO: connect Flask backend here
  // return fetch('/api/generate-plans', { method: 'POST', body: JSON.stringify(preferences) });
  
  return new Promise(resolve => {
    setTimeout(() => {
      const major = mockMajors.find(m => m.id === preferences.majorId);
      const remainingCourses = mockCourses.filter(course => 
        !preferences.completedCourses.includes(course.id) &&
        (major?.requiredCourses.includes(course.code) || major?.electiveCourses.includes(course.code))
      );

      const results: OptimizationResult[] = optimizationStrategies.map(strategy => {
        let coursesForStrategy = [...remainingCourses];
        let expectedGPA = 3.1;
        let graduationDate = "Spring 2026";
        let insights: string[] = [];

        if (strategy.id === 'max-gpa') {
          coursesForStrategy = coursesForStrategy.sort((a, b) => b.avgGPA - a.avgGPA);
          expectedGPA = 3.4;
          graduationDate = "Fall 2026";
          insights = [
            "Prioritizes courses with higher average GPAs",
            "Extends graduation by one semester for better grades",
            "Recommends lighter course loads per semester"
          ];
        } else if (strategy.id === 'graduate-fast') {
          coursesForStrategy = coursesForStrategy.sort((a, b) => a.difficulty - b.difficulty);
          expectedGPA = 2.9;
          graduationDate = "Spring 2026";
          insights = [
            "Focuses on prerequisite chain completion",
            "Higher course loads to graduate faster",
            "May require more study time per semester"
          ];
        } else {
          expectedGPA = 3.2;
          graduationDate = "Summer 2026";
          insights = [
            "Balances GPA maintenance with timely graduation",
            "Moderate course loads with strategic sequencing",
            "Optimal mix of difficult and manageable courses"
          ];
        }

        const semesters: SemesterPlan[] = [
          {
            semester: "Fall 2024",
            courses: coursesForStrategy.slice(0, 3),
            totalCredits: coursesForStrategy.slice(0, 3).reduce((sum, c) => sum + c.credits, 0),
            expectedGPA: expectedGPA + 0.1,
            workload: coursesForStrategy.slice(0, 3).reduce((sum, c) => sum + c.workload, 0)
          },
          {
            semester: "Spring 2025", 
            courses: coursesForStrategy.slice(3, 6),
            totalCredits: coursesForStrategy.slice(3, 6).reduce((sum, c) => sum + c.credits, 0),
            expectedGPA: expectedGPA - 0.1,
            workload: coursesForStrategy.slice(3, 6).reduce((sum, c) => sum + c.workload, 0)
          }
        ];

        return {
          strategy,
          semesters,
          totalGPA: expectedGPA,
          totalWorkload: strategy.id === 'graduate-fast' ? 55 : strategy.id === 'max-gpa' ? 35 : 45,
          degreeProgress: 25,
          graduationDate,
          insights
        };
      });

      resolve(results);
    }, 3000);
  });
};

export const parseSyllabus = async (file: File): Promise<any> => {
  // TODO: connect Flask backend here
  // const formData = new FormData();
  // formData.append('syllabus', file);
  // return fetch('/api/parse-syllabus', { method: 'POST', body: formData });
  
  return new Promise(resolve => {
    setTimeout(() => {
      resolve({
        assignments: [
          { name: "Homework 1", dueDate: "2024-02-15", weight: 10 },
          { name: "Midterm Exam", dueDate: "2024-03-15", weight: 25 },
          { name: "Final Project", dueDate: "2024-04-30", weight: 30 }
        ],
        syllabus: "Parsed syllabus content here..."
      });
    }, 1500);
  });
};