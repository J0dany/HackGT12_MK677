import { SemesterPlanner } from '@/components/semester-planner';

const Index = () => {
  return <SemesterPlanner />;
};

export default Index;
