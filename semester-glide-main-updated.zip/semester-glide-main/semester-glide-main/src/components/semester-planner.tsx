import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { GlassCard } from '@/components/ui/glass-card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Search, Sparkles, Calendar, Clock, GraduationCap, Target, BookOpen, Star } from 'lucide-react';
import { getCourses, getMajors, parseDegreeWorks, generateOptimizedPlans, Course, Major, DegreeProgress, OptimizationResult } from '@/lib/mockApi';

interface PlannerState {
  step: 'major' | 'existing-courses' | 'preferences' | 'optimizing' | 'results';
  selectedMajor: Major | null;
  completedCourses: string[];
  selectedCourses: string[];
  gpaGoal: number;
  creditLimit: number;
  difficultyBalance: number;
  extracurriculars: number;
  courses: Course[];
  majors: Major[];
  searchQuery: string;
  degreeProgress: DegreeProgress | null;
  optimizationResults: OptimizationResult[];
  uploadMethod: 'pdf' | 'manual';
}

export const SemesterPlanner: React.FC = () => {
  const [state, setState] = useState<PlannerState>({
    step: 'major',
    selectedMajor: null,
    completedCourses: [],
    selectedCourses: [],
    gpaGoal: 3.5,
    creditLimit: 16,
    difficultyBalance: 3,
    extracurriculars: 5,
    courses: [],
    majors: [],
    searchQuery: '',
    degreeProgress: null,
    optimizationResults: [],
    uploadMethod: 'manual'
  });

  React.useEffect(() => {
    Promise.all([getCourses(), getMajors()]).then(([courses, majors]) => {
      setState(prev => ({ ...prev, courses, majors }));
    });
  }, []);

  const filteredCourses = state.courses.filter(course =>
    course.code.toLowerCase().includes(state.searchQuery.toLowerCase()) ||
    course.name.toLowerCase().includes(state.searchQuery.toLowerCase())
  );

  const toggleCourse = (courseId: string) => {
    setState(prev => ({
      ...prev,
      selectedCourses: prev.selectedCourses.includes(courseId)
        ? prev.selectedCourses.filter(id => id !== courseId)
        : [...prev.selectedCourses, courseId]
    }));
  };

  const selectMajor = (major: Major) => {
    setState(prev => ({ ...prev, selectedMajor: major, step: 'existing-courses' }));
  };

  const handlePDFUpload = async (file: File) => {
    setState(prev => ({ ...prev, step: 'optimizing' }));
    const degreeProgress = await parseDegreeWorks(file);
    setState(prev => ({ 
      ...prev, 
      degreeProgress,
      completedCourses: degreeProgress.completedCourses,
      step: 'preferences'
    }));
  };

  const proceedToPreferences = () => {
    setState(prev => ({ ...prev, step: 'preferences' }));
  };

  const generatePlans = async () => {
    setState(prev => ({ ...prev, step: 'optimizing' }));
    
    const results = await generateOptimizedPlans({
      majorId: state.selectedMajor!.id,
      completedCourses: state.completedCourses,
      gpaGoal: state.gpaGoal,
      creditLimit: state.creditLimit,
      difficultyBalance: state.difficultyBalance,
      extracurriculars: state.extracurriculars
    });

    setState(prev => ({ 
      ...prev, 
      step: 'results',
      optimizationResults: results 
    }));
  };

  const toggleCompletedCourse = (courseId: string) => {
    setState(prev => ({
      ...prev,
      completedCourses: prev.completedCourses.includes(courseId)
        ? prev.completedCourses.filter(id => id !== courseId)
        : [...prev.completedCourses, courseId]
    }));
  };

  const resetPlanner = () => {
    setState(prev => ({ 
      ...prev, 
      step: 'major',
      optimizationResults: [],
      selectedMajor: null,
      completedCourses: [],
      degreeProgress: null
    }));
  };

  return (
    <div className="min-h-screen w-full relative">
      {/* Floating Header */}
      <motion.header 
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="fixed top-6 left-1/2 transform -translate-x-1/2 z-50"
      >
        <GlassCard className="px-8 py-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <GraduationCap className="w-6 h-6 text-gt-gold" />
              <h1 className="text-xl font-bold gradient-text">Rate My Semester</h1>
            </div>
            <div className="w-2 h-2 bg-accent rounded-full animate-pulse" />
            <span className="text-sm text-muted-foreground">Georgia Tech AI Planner</span>
          </div>
        </GlassCard>
      </motion.header>

      {/* Main Content */}
      <div className="pt-32 pb-20 px-6 max-w-6xl mx-auto">
        <AnimatePresence mode="wait">
          {state.step === 'major' && (
            <motion.div
              key="major"
              initial={{ opacity: 0, y: 60 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -60 }}
              transition={{ duration: 0.6, ease: [0.34, 1.56, 0.64, 1] }}
              className="space-y-8"
            >
              <div className="text-center space-y-6 mb-16">
                <motion.h2 
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="text-5xl md:text-6xl font-bold gradient-text-warm"
                >
                  Choose Your Major
                </motion.h2>
                <motion.p 
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  className="text-xl text-muted-foreground max-w-2xl mx-auto"
                >
                  Select your degree program to get personalized graduation planning
                </motion.p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {state.majors.map((major, index) => (
                  <motion.div
                    key={major.id}
                    initial={{ y: 40, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.6 + index * 0.1 }}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => selectMajor(major)}
                    className="glass-card p-6 cursor-pointer hover:bg-accent/10 transition-all duration-300"
                  >
                    <div className="space-y-4">
                      <div className="text-center">
                        <GraduationCap className="w-12 h-12 mx-auto text-accent mb-3" />
                        <h3 className="text-xl font-bold">{major.name}</h3>
                        <p className="text-sm text-muted-foreground">{major.department}</p>
                      </div>
                      <div className="text-center">
                        <span className="text-2xl font-bold text-gt-gold">{major.totalCredits}</span>
                        <span className="text-sm text-muted-foreground ml-1">credits</span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {state.step === 'existing-courses' && (
            <motion.div
              key="existing-courses"
              initial={{ opacity: 0, y: 60 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -60 }}
              transition={{ duration: 0.6, ease: [0.34, 1.56, 0.64, 1] }}
              className="space-y-8"
            >
              <div className="text-center space-y-6 mb-16">
                <motion.h2 
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="text-5xl md:text-6xl font-bold gradient-text-warm"
                >
                  Track Your Progress
                </motion.h2>
                <motion.p 
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  className="text-xl text-muted-foreground max-w-2xl mx-auto"
                >
                  Upload your DegreeWorks PDF or manually select completed courses
                </motion.p>
              </div>

              <GlassCard variant="large" className="p-8">
                <div className="space-y-6">
                  <div className="flex justify-center gap-4">
                    <Button
                      variant={state.uploadMethod === 'pdf' ? 'default' : 'outline'}
                      onClick={() => setState(prev => ({ ...prev, uploadMethod: 'pdf' }))}
                      className="px-8"
                    >
                      Upload DegreeWorks PDF
                    </Button>
                    <Button
                      variant={state.uploadMethod === 'manual' ? 'default' : 'outline'}
                      onClick={() => setState(prev => ({ ...prev, uploadMethod: 'manual' }))}
                      className="px-8"
                    >
                      Manual Selection
                    </Button>
                  </div>

                  {state.uploadMethod === 'pdf' ? (
                    <div className="text-center space-y-4">
                      <div className="border-2 border-dashed border-accent/30 rounded-xl p-12">
                        <input
                          type="file"
                          accept=".pdf"
                          onChange={(e) => e.target.files?.[0] && handlePDFUpload(e.target.files[0])}
                          className="hidden"
                          id="pdf-upload"
                        />
                        <label htmlFor="pdf-upload" className="cursor-pointer">
                          <div className="space-y-4">
                            <div className="w-16 h-16 mx-auto bg-accent/20 rounded-full flex items-center justify-center">
                              <BookOpen className="w-8 h-8 text-accent" />
                            </div>
                            <div>
                              <p className="font-semibold">Drop your DegreeWorks PDF here</p>
                              <p className="text-sm text-muted-foreground">or click to browse</p>
                            </div>
                          </div>
                        </label>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                        <Input
                          placeholder="Search completed courses..."
                          value={state.searchQuery}
                          onChange={(e) => setState(prev => ({ ...prev, searchQuery: e.target.value }))}
                          className="pl-10 h-12 glass-button border-white/30"
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-96 overflow-y-auto">
                        {filteredCourses.map((course) => (
                          <motion.div
                            key={course.id}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => toggleCompletedCourse(course.id)}
                            className={`p-4 rounded-xl cursor-pointer transition-all duration-300 ${
                              state.completedCourses.includes(course.id)
                                ? 'bg-success/20 border-success border-2'
                                : 'glass-button border border-white/20'
                            }`}
                          >
                            <div className="space-y-2">
                              <div className="flex justify-between items-start">
                                <h4 className="font-semibold text-sm">{course.code}</h4>
                                <Badge variant="secondary" className="text-xs">
                                  {course.credits} cr
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground line-clamp-2">
                                {course.name}
                              </p>
                            </div>
                          </motion.div>
                        ))}
                      </div>

                      <div className="text-center">
                        <Button onClick={proceedToPreferences} size="lg" className="px-12">
                          Continue to Preferences
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </GlassCard>
            </motion.div>
          )}

          {state.step === 'preferences' && (
            <motion.div
              key="preferences"
              initial={{ opacity: 0, y: 60 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -60 }}
              transition={{ duration: 0.6, ease: [0.34, 1.56, 0.64, 1] }}
              className="space-y-8"
            >
              <div className="text-center space-y-6 mb-16">
                <motion.h2 
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="text-5xl md:text-6xl font-bold gradient-text-warm"
                >
                  Set Your Preferences
                </motion.h2>
                <motion.p 
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  className="text-xl text-muted-foreground max-w-2xl mx-auto"
                >
                  Configure your goals to generate 3 optimized graduation plans
                </motion.p>
              </div>

              {/* Preferences */}
              <motion.div
                initial={{ y: 40, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-6"
              >
                <GlassCard className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Target className="w-5 h-5 text-success" />
                      <h4 className="font-semibold">GPA Goal</h4>
                    </div>
                    <div className="space-y-2">
                      <Slider
                        value={[state.gpaGoal]}
                        onValueChange={([value]) => setState(prev => ({ ...prev, gpaGoal: value }))}
                        min={2.0}
                        max={4.0}
                        step={0.1}
                        className="w-full"
                      />
                      <div className="text-center text-2xl font-bold text-accent">
                        {state.gpaGoal.toFixed(1)}
                      </div>
                    </div>
                  </div>
                </GlassCard>

                <GlassCard className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-warning" />
                      <h4 className="font-semibold">Credit Limit</h4>
                    </div>
                    <div className="space-y-2">
                      <Slider
                        value={[state.creditLimit]}
                        onValueChange={([value]) => setState(prev => ({ ...prev, creditLimit: value }))}
                        min={12}
                        max={20}
                        step={1}
                        className="w-full"
                      />
                      <div className="text-center text-2xl font-bold text-warning">
                        {state.creditLimit} credits
                      </div>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>

              {/* Generate Plans Button */}
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 1.0 }}
                className="text-center"
              >
                <Button
                  onClick={generatePlans}
                  size="lg"
                  className="px-12 py-6 text-lg font-semibold bg-gradient-to-r from-accent to-primary hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-accent/25"
                >
                  <Sparkles className="w-6 h-6 mr-2" />
                  Generate 3 Optimization Plans
                </Button>
              </motion.div>
            </motion.div>
          )}

          {state.step === 'optimizing' && (
            <motion.div
              key="optimizing"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.1 }}
              className="flex items-center justify-center min-h-[60vh]"
            >
              <GlassCard variant="floating" className="p-12 text-center max-w-md">
                <div className="space-y-6">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                    className="mx-auto w-16 h-16 rounded-full bg-gradient-to-r from-accent to-primary flex items-center justify-center"
                  >
                    <Sparkles className="w-8 h-8 text-white" />
                  </motion.div>
                  <div>
                    <h3 className="text-2xl font-bold mb-2">Optimizing Your Plan</h3>
                    <p className="text-muted-foreground">
                      Analyzing course data, professor ratings, and your preferences...
                    </p>
                  </div>
                  <Progress value={75} className="w-full" />
                </div>
              </GlassCard>
            </motion.div>
          )}

          {state.step === 'results' && state.optimizationResults.length > 0 && (
            <motion.div
              key="results"
              initial={{ opacity: 0, y: 60 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: [0.34, 1.56, 0.64, 1] }}
              className="space-y-8"
            >
              {/* Results Header */}
              <div className="text-center space-y-4">
                <h2 className="text-4xl font-bold gradient-text">Your 3 Optimization Plans</h2>
                <p className="text-lg text-muted-foreground">
                  Choose the strategy that best fits your goals
                </p>
              </div>

              {/* Three Plan Options */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {state.optimizationResults.map((result, index) => (
                  <motion.div
                    key={result.strategy.id}
                    initial={{ y: 60, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: index * 0.2 }}
                    className="space-y-6"
                  >
                    <GlassCard className="p-6">
                      <div className="text-center space-y-4">
                        <div className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center ${
                          result.strategy.id === 'max-gpa' ? 'bg-success/20' :
                          result.strategy.id === 'graduate-fast' ? 'bg-warning/20' : 'bg-accent/20'
                        }`}>
                          {result.strategy.id === 'max-gpa' && <Star className="w-8 h-8 text-success" />}
                          {result.strategy.id === 'graduate-fast' && <Clock className="w-8 h-8 text-warning" />}
                          {result.strategy.id === 'balanced' && <Target className="w-8 h-8 text-accent" />}
                        </div>
                        <div>
                          <h3 className="text-xl font-bold">{result.strategy.name}</h3>
                          <p className="text-sm text-muted-foreground">{result.strategy.description}</p>
                        </div>
                      </div>

                      {/* Key Metrics */}
                      <div className="grid grid-cols-2 gap-4 mt-6">
                        <div className="text-center">
                          <div className="text-2xl font-bold text-success">
                            {result.totalGPA.toFixed(1)}
                          </div>
                          <div className="text-xs text-muted-foreground">Expected GPA</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-accent">
                            {result.totalWorkload}h
                          </div>
                          <div className="text-xs text-muted-foreground">Weekly Load</div>
                        </div>
                      </div>

                      <div className="text-center mt-4">
                        <div className="text-lg font-semibold text-gt-gold">
                          {result.graduationDate}
                        </div>
                        <div className="text-xs text-muted-foreground">Graduation</div>
                      </div>

                      {/* Sample Semester */}
                      <div className="mt-6 space-y-3">
                        <h4 className="font-semibold text-sm">Sample Semester:</h4>
                        <div className="space-y-2">
                          {result.semesters[0]?.courses.slice(0, 3).map((course) => (
                            <div key={course.id} className="glass-button p-2 rounded text-xs">
                              <div className="font-medium">{course.code}</div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Key Insights */}
                      <div className="mt-6 space-y-2">
                        <h4 className="font-semibold text-sm">Key Insights:</h4>
                        <div className="space-y-1">
                          {result.insights.slice(0, 2).map((insight, idx) => (
                            <div key={idx} className="text-xs text-muted-foreground flex items-start gap-2">
                              <div className="w-1 h-1 bg-accent rounded-full mt-2 flex-shrink-0" />
                              <span>{insight}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <Button className="w-full mt-6" variant="outline">
                        View Full Plan
                      </Button>
                    </GlassCard>
                  </motion.div>
                ))}
              </div>

              {/* Action Buttons */}
              <div className="flex justify-center gap-4">
                <Button onClick={resetPlanner} variant="outline" size="lg">
                  Plan Another Semester
                </Button>
                <Button size="lg" className="bg-gradient-to-r from-success to-accent">
                  Export Plan
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Background Elements */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gt-gold/5 rounded-full blur-3xl" />
      </div>
    </div>
  );
};