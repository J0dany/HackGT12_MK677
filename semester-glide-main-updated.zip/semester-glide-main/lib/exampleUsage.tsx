/**
 * lib/exampleUsage.tsx
 * Example React client that calls lib/api.ts. This is a drop-in example you can import into a page.
 */

import React, { useState } from "react";
import { optimizePlan, getCourses } from "./api";

export default function ExampleUsage() {
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState(null);

  async function runExample() {
    setLoading(true);
    const courses = await getCourses();
    const input = {
      courses: courses,
      targetGPA: 3.6,
      semestersLeft: 6,
      creditLimit: 18,
      extracurriculars: [{ name: "Robotics Club", hoursPerWeek: 6 }]
    };
    const result = await optimizePlan(input);
    setPlan(result);
    setLoading(false);
  }

  return (
    <div style={{ padding: 20 }}>
      <button onClick={runExample} disabled={loading}>
        {loading ? "Optimizing..." : "Run Mock Optimization"}
      </button>
      {plan && (
        <pre style={{ whiteSpace: "pre-wrap", marginTop: 12 }}>{JSON.stringify(plan, null, 2)}</pre>
      )}
    </div>
  );
}