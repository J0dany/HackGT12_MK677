/**
 * lib/api.ts
 * Centralized API layer for Rate My Semester — Flask-compatible.
 * Replace mock implementations with real fetch() calls to your Flask backend.
 *
 * TODO: Backend team: implement corresponding Flask routes:
 *   GET  /api/courses
 *   GET  /api/professors
 *   POST /api/optimize-plan
 *   POST /api/parse-syllabus
 */

const BASE_URL = process.env.NEXT_PUBLIC_FLASK_API_URL || "http://localhost:5000";

export async function getCourses() {
  // TODO: Replace mock return with:
  // const res = await fetch(`${BASE_URL}/api/courses`);
  // return await res.json();
  return [
    { courseId: "ECE2020", title: "Intro to ECE", credits: 3, avgGPA: 3.2, priority: "medium" },
    { courseId: "MATH2551", title: "Multivariable Calculus", credits: 4, avgGPA: 2.8, priority: "high" },
    { courseId: "CS1371", title: "Intro to Computing", credits: 3, avgGPA: 3.5, priority: "low" }
  ];
}

export async function getProfessors(query) {
  // TODO: Replace with Flask endpoint that scrapes RateMyProfessor or returns cached data.
  // const res = await fetch(`${BASE_URL}/api/professors?q=${encodeURIComponent(query)}`);
  // return await res.json();
  return [
    { name: "Dr. Smith", dept: "ECE", rating: 4.2, reviews: ["Excellent lecture clarity", "Hard but fair exams"] },
    { name: "Dr. Nguyen", dept: "MATH", rating: 3.6, reviews: ["Great office hours", "Fast-paced"] }
  ];
}

export async function optimizePlan(input) {
  // Input shape example:
  // { courses: [...], targetGPA: 3.6, semestersLeft: 6, creditLimit: 18, extracurriculars: [...] }
  // TODO: Replace with:
  // const res = await fetch(`${BASE_URL}/api/optimize-plan`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) });
  // return await res.json();

  console.log("Mock optimizePlan input:", input);

  // Return a realistic mock optimized plan
  return {
    success: true,
    generatedAt: new Date().toISOString(),
    semesters: [
      {
        term: "Fall 2025",
        courses: [
          { courseId: "ECE2020", title: "Intro to ECE", credits: 3, hoursPerWeek: 6, avgGPA: 3.2 },
          { courseId: "CS1371", title: "Intro to Computing", credits: 3, hoursPerWeek: 5, avgGPA: 3.5 }
        ],
        projectedGPA: 3.45,
        totalCredits: 6,
        workloadHours: 11
      },
      {
        term: "Spring 2026",
        courses: [
          { courseId: "MATH2551", title: "Multivariable Calculus", credits: 4, hoursPerWeek: 10, avgGPA: 2.8 }
        ],
        projectedGPA: 3.35,
        totalCredits: 4,
        workloadHours: 10
      }
    ],
    overallProjectedGPA: 3.4,
    notes: ["Mock plan: swap heavy course to spring if you prefer lower load in fall."]
  };
}

export async function parseSyllabus(file) {
  // TODO: Replace with a multipart/form-data POST to Flask endpoint /api/parse-syllabus
  // Example:
  // const form = new FormData();
  // form.append('file', file);
  // const res = await fetch(`${BASE_URL}/api/parse-syllabus`, { method: 'POST', body: form });
  // return await res.json();

  console.log("Mock parseSyllabus file:", file && file.name);

  return {
    filename: file ? file.name : "mock_syllabus.pdf",
    deliverables: [
      { title: "Quiz 1", date: "2025-09-30", weight: 5 },
      { title: "Midterm 1", date: "2025-10-20", weight: 25 },
      { title: "Final Exam", date: "2025-12-12", weight: 50 }
    ],
    gradingBreakdown: [
      { component: "Homework", percent: 20 },
      { component: "Quizzes", percent: 10 },
      { component: "Exams", percent: 70 }
    ]
  };
}